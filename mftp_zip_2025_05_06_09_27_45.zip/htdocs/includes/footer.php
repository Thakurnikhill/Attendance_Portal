
<footer style="
    margin: 8px 0 4px 0;
    text-align: center;
    font-size: 0.98em;
    color: #b55a52;
    width: 100%;
    letter-spacing: 0.2px;
">
  &copy; <?php echo date('Y'); ?> GBU Attendance Portal &amp; developed by
  <a href="https://www.linkedin.com/in/nikhil-thakur-78a442260/"
     target="_blank"
     style="color:#d94b3f;text-decoration:underline;font-weight:500;">
    Nikhil Thakur
  </a>
</footer>
